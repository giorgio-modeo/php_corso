<?php $this->layout('layout', ['title' => 'Rubrica']);?>

<?php print_r($utenti);?>
<?php $this->push('css') ?>
<link href="/css/login.css" rel="stylesheet">
<?php $this->end() ?>